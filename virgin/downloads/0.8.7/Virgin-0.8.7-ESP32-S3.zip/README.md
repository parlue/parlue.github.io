﻿# Virgin 0.8.7 für ESP32-S3

| Variante | Konfiguration |
|---|---|
| mini_no_psram | Ohne PSRAM, 32 KiB Hash, Suchpfad bis 24 Halbzüge |
| mini_psram_qspi | QSPI-PSRAM, 1 MiB Hash, Suchpfad bis 64 Halbzüge |
| mini_psram_opi | OPI-PSRAM, 1 MiB Hash, Suchpfad bis 64 Halbzüge |

Jeder Ordner enthält `bootloader.bin`, `partitions.bin` und `firmware.bin` aus
demselben Build. Die Firmware meldet Version 0.8.7 und enthält das globale
Eröffnungsbuch. `OwnBook` ist standardmäßig an und über UCI schaltbar.

Diese Images sind für ESP32-S3, die separate Core2-Firmware liegt im Ordner
`esp32-core2`. Der Release-Build hat keine Geräte geflasht. Bestehende Geräte
bleiben bis zum eigenen Update auf ihrem installierten Stand.

Flash-Offsets für ESP32-S3: Bootloader `0x0`, Partitionen `0x8000`, Firmware
`0x10000`. Build: `platformio run -d esp32 -e <Variante>`. Die passende Variante
entsprechend der PSRAM-Ausstattung des Boards wählen.
